jx86
====

Java Library for Generating x86 Code.

